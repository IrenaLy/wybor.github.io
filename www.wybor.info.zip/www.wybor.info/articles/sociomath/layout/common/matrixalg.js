function areEqualMatricies( firstMatrix, secondMatrix )
{
    if( firstMatrix.length != secondMatrix.length ) return false;
    for( var i = 0; i < firstMatrix.length; i ++ )
    {
        if( isArray( firstMatrix[ i ] ) || isArray( secondMatrix[ i ] )  )
        {
            if( ! isArray( firstMatrix[ i ] ) && isArray( secondMatrix[ i ] ) ) return false;
            if( ! areEqualMatricies( firstMatrix[ i ], secondMatrix[ i ] ) ) return false;
        }
        if( firstMatrix[ i ] - secondMatrix[ i ] > .0001 ||
                    firstMatrix[ i ] - secondMatrix[ i ] 