function appendTable( givenParent, givenDispatch )
{
    var myContainer     = makeChildElement( givenParent,    "div",      "dispatch-container" );
    var myTable         = makeChildElement( myContainer,    "table",    "dispatch-table" );
    var myTBody         = makeChildElement( myTable,        "tbody",    "dispatch-body" );

    for( var i = 0; i 