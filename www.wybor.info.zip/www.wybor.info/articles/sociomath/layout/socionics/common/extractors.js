function timNameById( givenTimId )
{
    return linearRepresentation[ givenTimId ].nick;
}
function timFullNameById( givenTimId )
{
    var myTim = linearRepresentation[ givenTimId ];
    return myTim.jung + " ( " + myTim.mbti + ", '" + myTim.nick + "' )";
}
function relationNameById( givenRelationId )
{
    return linearRepresentation[ givenRelationId ].rel;
}
function relationNameByTimIds( firstTimId, secondTimId )
{
    // Кем второй ТИМ приходится первому

    var myRelationId = relationIdByTimIds( firstTimId, secondTimId );
    return relationNameById( myRelationId );
}
function relationIdByTimIds( firstTimId, secondTimId )
{
    var firstTimMatrix  = linearRepresentation[ firstTimId ].matrix;
    var secondTimMatrix = linearRepresentation[ secondTimId ].matrix;
    var transforMatrix  = productOfMatricies( secondTimMatrix, transposeMatrix( firstTimMatrix ) );
    return lookupRelationId( transforMatrix );
}
function lookupRelationIdByJung( givenJung )
{
    for( i = 0; i 