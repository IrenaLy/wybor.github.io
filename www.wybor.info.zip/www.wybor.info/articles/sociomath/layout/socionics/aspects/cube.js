function appendCubeSelector( givenParent, givenInitialSelection )
{
    removeAllChildren( givenParent );
    function timCubeOptionMaker()
    {
        this.range = linearRepresentation.length;
        this.caption = function ( givenTimId ) { return timFullNameById( givenTimId ) };
    }
    var timOptions = new timCubeOptionMaker();
    var mySelector = makeSelector( givenParent, timOptions );

    var myTable = makeChildElement( givenParent, "table", "container-table" );
    var myTBody = makeChildElement( myTable, "tbody", "container-tbody" );

    var myRow = makeChildElement( myTBody, "tr", "container-row" );
    var myCube = makeChildElement( myRow, "td", "container-cube" );
    var myAspects = makeChildElement( myRow, "td", "container-aspects" );

    function makeTimCubeSelection( givenTimId )
    {
        appendCube( myCube, givenTimId );
        appendPsychicFunctions( myAspects, givenTimId );
        mySelector.selectedIndex = givenTimId;
    }
    mySelector.onchange = function ()
    {
        makeTimCubeSelection( mySelector.selectedIndex );
    };
    makeTimCubeSelection( givenInitialSelection );
}
function makeSelector( givenParent, givenOptions  )
{
    var myForm      = makeChildElement( givenParent, "form", "selector-form" );
    var mySelect    = makeChildElement( myForm, "select", "selector-select" );
    for( i = 0; i 