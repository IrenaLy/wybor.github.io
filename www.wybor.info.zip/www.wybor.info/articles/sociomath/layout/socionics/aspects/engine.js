function lookupPathAspectIcon( givenAspect )
{
    return "../layout/socionics/aspects/images/" + givenAspect + ".gif";
}
function appendPsychicFunctions( givenParent, givenTimId )
{
    removeAllChildren( givenParent );
    
    var myTable = makeChildElement( givenParent, "table", "psychic-functions-table" );
    var myTBody = makeChildElement( myTable, "tbody", "psychic-functions-tbody" );

    var myTHead = makeChildElement( myTable, "thead", "psychic-functions-headers" );
    var myTHeadRow = makeChildElement( myTHead, "tr", "psychic-functions-header-row" );

    var myNameHeader = makeChildElement( myTHeadRow, "td", "psychic-functions-header-name" );
    myNameHeader.appendChild( document.createTextNode( "Психо-функция" ) );

    var myDimensionHeader = makeChildElement( myTHeadRow, "td", "psychic-functions-header-dim" );
    myDimensionHeader.appendChild( document.createTextNode( "Размерность" ) );

    var myAspectHeader = makeChildElement( myTHeadRow, "td", "psychic-functions-header-aspect" );
    myAspectHeader.appendChild( document.createTextNode( "Заполняющий аспект" ) );

    for( var i = 0; i 