function makeReininEngineTALANOV()  
{
    return function ( givenSlidersSelection )
        {
            var myTransformation = makeReininTimToDichotomyTransformer();

            givenSlidersSelection[ 15 ]  = 1;
            var myTimCoefficients = transformPoint( myTransformation, givenSlidersSelection );

            //var myProcessor = new ResultsetProcessor( function ( x ) { return x / 16; } );

            var myProcessor = new ResultsetProcessor( function ( x ) { return x/15  - 1 / 15; } );
            
            processObject( myTimCoefficients, myProcessor );

            // alert( "maximum = " + myProcessor.max + ", min = " + myProcessor.min + ", total = " + myProcessor.total );

            return myProcessor.result;
        };
}
function sliderDensity( givenDichotomyId, givenTimId, givenValue )
{
    if( givenValue > 1 || givenValue < -1 ) return 0;
     
    var myDichotomy = reininDichotomies[ givenDichotomyId ];
    var myReininCoef = myDichotomy.tim[ givenTimId ];
    
    // так можно уменьшить относительный вклад 0-й дихотомии:
    // if( givenDichotomyId == 0 ) return ( ( 1 / 10 )* myReininCoef * givenValue + ( 1 / 2 ) ); 
    
    return ( ( 4 / 9 )* myReininCoef * givenValue + ( 1 / 2 ) );
}
function makeReininEngine()
{
    return function ( givenSliderSelection )
        {   
            
            var myResult = new Array(); 
            for( var i = 0; i < 16; i ++ ) myResult[ i ] = 1; 
            var myTotal = 0;   
            for( var myTimId = 0; myTimId < 16; myTimId ++ )
            {
                for( var myDichotomyId = 0; myDichotomyId < 15; myDichotomyId ++ )
                {
                    myResult[ myTimId ] *= sliderDensity( myDichotomyId, myTimId, 
                        givenSliderSelection[ myDichotomyId ] );
                }
                myTotal += myResult[ myTimId ];
            }
            for( var i = 0; i < 16; i ++ ) myResult[ i ] = myResult[ i ] / myTotal;
            return myResult;
        };
}
function ResultsetProcessor( givenAffineTransformation ) 
// считает профиль Таланова (или хрен знает что ещё), а не распределение вероятности на множестве ТИМов
{
    this.max = - 1000;
    this.min = 1000;
    this.total = 0;
    this.result = new Array();
    
    this.processValue = function( givenKey, givenValue, givenLevel )
        {
            var myResult = roundFloat( givenAffineTransformation( givenValue ) );
            
            this.result[ this.result.length ] = myResult;

                this.min = ( this.min > myResult ? myResult : this.min );
                this.max = ( this.max 